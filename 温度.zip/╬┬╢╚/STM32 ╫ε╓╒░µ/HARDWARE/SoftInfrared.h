/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                        ����NEC��������                                                                                         */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

#ifndef SOFTINFRARED_H_
#define SOFTINFRARED_H_

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "sys.h"
#include "delay.h"
#include "usart.h"

/**********************************************************************************************************/
/* �궨�� */
#define Send_Buffer_Size 100
#define Receive_Buffer_Size 100

#define AddrBitNum 4
#define DataBitNum 12

/**********************************************************************************************************/
/* ������ */
// ���ݷ��ͻ�����
extern unsigned int Send_Addr[AddrBitNum];
extern unsigned int Send_Data[DataBitNum];
extern unsigned int Send_Buffer[Send_Buffer_Size];

// ���ݽ��ջ�����
extern unsigned int Receive_Addr[AddrBitNum];
extern unsigned int Receive_Data[DataBitNum];
extern unsigned int Send_Buffer[Receive_Buffer_Size];

/**********************************************************************************************************/
/* ��ʼ������ */
void SoftInfrared_Init(void);

/**********************************************************************************************************/
/* Ӧ�ú��� */
// ���ú���
void SoftInfrared_SetAddr(unsigned int _addr[AddrBitNum]);
void SoftInfrared_SetData(unsigned int _data[DataBitNum]);

// ���ͺ���
void SoftInfrared_SendData(unsigned int data);

// ���ռ�⺯��
void SoftInfrared_Receive_Check(void);
// ���պ���
void SoftInfrared_Receive(void);


/**********************************************************************************************************/
/* �ڲ��������� */
// �źŷ���
void SoftInfrared_SendStartSignal(void);
void SoftInfrared_SendLogicHigh(void);
void SoftInfrared_SendLogicLow(void);
void SoftInfrared_SendEndSignal(void);
// 38 kHz�ز�
void SoftInfrared_CarrierWave(unsigned int time);
// ���뺯��
void SoftInfrared_HandleData(void);
// �������ݰ�
void SoftInfrared_SendFrame(unsigned int data[DataBitNum]);

/**********************************************************************************************************/
/* ���Դ��� */
// ���Ͳ��Ժ���
void SoftInfrared_SendTest(void);

#endif /* SOFTINFRARED_H_ */

