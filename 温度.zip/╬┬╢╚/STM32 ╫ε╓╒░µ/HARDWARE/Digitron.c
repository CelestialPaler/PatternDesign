/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                       �����(����)����                                                                                         */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "Digitron.h"

/**********************************************************************************************************/
// �ַ���
const unsigned char CharTable[17] = {
		        0x3f , 0x06 , 0x5b , 0x4f ,
				0x66 , 0x6d , 0x7d , 0x07 ,
				0x7f , 0x6f , 0x77 , 0x7c ,
				0x39 , 0x5e , 0x79 , 0x71 ,
				0x00 };

// �ֶα�
const unsigned char DigTable[9] = {
			0xFE, 0xFD, 0xFB, 0xF7,
			0xEF, 0xDF, 0xBF, 0x7F, 0xFF };

// ��ʾ��������
unsigned int Digitron_Buffer[8];

// ��������ָ��
u32 *DataBus[8] = {(u32*)&LOCK_D0,(u32*)&LOCK_D1,(u32*)&LOCK_D2,(u32*)&LOCK_D3,(u32*)&LOCK_D4,(u32*)&LOCK_D5,(u32*)&LOCK_D6,(u32*)&LOCK_D7};


/**********************************************************************************************************/
/* ��ʼ������ */
void Digitron_Init(void)
{
	// ��ʼ���ṹ��
	GPIO_InitTypeDef GPIO_InitStructure;

	// ��ʼ����������
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_5|GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// ��ʼ�����ʹ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// ��ʼ������ʹ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// ��ʾָ�������� ����ʱ��
void Digitron_Print(const unsigned int data[],const unsigned int time)
{
	int i;
	for(i=0;i<time;++i)
		Digitron_PrintOnce(data);
}

// ��ʾĬ�������� ����ʱ��
void Digitron_Print_Default(const unsigned int time)
{
	int i;
	for(i=0;i<time;++i)
		Digitron_PrintOnce_Default();
}

// ����Ĭ��������
void Digitron_SetData(const unsigned int data)
{
	int i;
	unsigned int tempdata[8];
	tempdata[0]=data/10000000%10;
	tempdata[1]=data/1000000%10;
	tempdata[2]=data/100000%10;
	tempdata[3]=data/10000%10;
	tempdata[4]=data/1000%10;
	tempdata[5]=data/100%10;
	tempdata[6]=data/10%10;
	tempdata[7]=data/1%10;
	for(i=0;i<8;++i)
		Digitron_Buffer[i] = tempdata[i];
}

/**********************************************************************************************************/
/* �ڲ��������� */
// ������ʾ����(Ĭ������)
void Digitron_PrintOnce_Default(void)
{
	int i;
	for(i=0 ;i<8;++i)
	{
		LOCK_OE2 = 1;
		LOCK_OE1 = 1; //����ʾ

		delay_us(5);
		LOCK_LE2 = 0;
		LOCK_LE1 = 1; //��ȡ
		delay_us(5);
		if(i==1||i==5)		
			Digitron_DataBusUpdate(CharTable[Digitron_Buffer[i]]+0x80);
		else
			Digitron_DataBusUpdate(CharTable[Digitron_Buffer[i]]);
		delay_us(5);
		LOCK_LE1 = 0; //��ס
		LOCK_LE2 = 1;
		delay_us(5);
		Digitron_DataBusUpdate(DigTable[i]);
		delay_us(5);
		LOCK_LE2 = 0;
		delay_us(5);

		LOCK_D1 = 0;

		LOCK_OE1 = 0;
		LOCK_OE2 = 0; //��ʾ

		delay_ms(1);
	}
	LOCK_OE2 = 1;
	LOCK_OE1 = 1; //����ʾ

	delay_us(5);
	LOCK_LE2 = 0;
	LOCK_LE1 = 1; //��ȡ
	delay_us(5);
	Digitron_DataBusUpdate(0x00);
	delay_us(5);
	LOCK_LE1 = 0; //��ס
	LOCK_LE2 = 1;
	delay_us(5);
	Digitron_DataBusUpdate(0xff);
	delay_us(5);
	LOCK_LE2 = 0;
	delay_us(5);

	LOCK_D1 = 0;

	LOCK_OE1 = 0;
	LOCK_OE2 = 0; //��ʾ
}

// ������ʾ����(ָ������)
void Digitron_PrintOnce(const unsigned int data[8])
{
	int i;
	for(i=0 ;i<8;++i)
	{
		LOCK_OE2 = 1;
		LOCK_OE1 = 1; //����ʾ

		delay_us(5);
		LOCK_LE2 = 0;
		LOCK_LE1 = 1; //��ȡ
		delay_us(5);
		/*
		if(i==1||i==5)		
			Digitron_DataBusUpdate(CharTable[data[i]]&&0x7F);
		else
			Digitron_DataBusUpdate(CharTable[data[i]]);
		*/
		delay_us(5);
		LOCK_LE1 = 0; //��ס
		LOCK_LE2 = 1;
		delay_us(5);
		Digitron_DataBusUpdate(DigTable[i]);
		delay_us(5);
		LOCK_LE2 = 0;
		delay_us(5);

		LOCK_D1 = 0;

		LOCK_OE1 = 0;
		LOCK_OE2 = 0; //��ʾ

		delay_ms(1);
	}
}

// �������߸���
void Digitron_DataBusUpdate(unsigned char newData)
{
	int i;
	for(i=0;i<8;++i)
		*DataBus[i]=!((int)(newData&(0x01<<i))>>i);
}

// �����������
void Digitron_DataBusClear(void)
{
	int i;
	for(i=0;i<8;++i)
		*DataBus[i]=0;
}

// ������º���
void Digitron_DataUpdate(const unsigned int newData[])
{
	int i;
	for(i=0;i<8;++i)
		Digitron_Buffer[i] = newData[i];
}
