/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                           ���ߺ���                                                                                                */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "Tools.h"

// �¶Ȼ��㺯��
float TemperatureCal(u16 voltage)
{
	float temp;
	temp = (float)voltage * 3.3 / 4096 * 1000;
	temp = temp * 10 / 3;
	return temp;
}

void Usart1_Send(char* data)
{
	int i=0;
	while(data[i])
	{
		USART_SendData(USART1,data[i]);
		while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
		i++;
	}
}
