/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                           LED����                                                                                                 */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "LED.h"

/**********************************************************************************************************/
/* ��ʼ������ */
void LED_Init(void)
{
	// ��ʼ���ṹ��
	GPIO_InitTypeDef GPIO_InitStructure;
	// ʹ�����ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	// ���г�ʼ��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOC,GPIO_Pin_13|GPIO_Pin_14);
}

/**********************************************************************************************************/
/* Ӧ�ú��� */
void LED_Blink(enum LED_Name name,enum Blink_Mode mode)
{
	int i;
	switch(mode)
	{
	case Single:
		for(i=0;i<1;++i)
			LED_Blink_Single(name);
		break;
	case Double:
		for(i=0;i<2;++i)
			LED_Blink_Single(name);
		break;
	case Triple:
		for(i=0;i<3;++i)
			LED_Blink_Single(name);
		break;
	}
}

void SysBlink(void)
{
	LED0 =!LED0;
}

void ComOK(void)
{
	LED_On(COM);
}
	


/**********************************************************************************************************/
/* �ڲ��������� */
void LED_Blink_Single(enum LED_Name name)
{
	LED_On(name);
	delay_ms(100);
	LED_Off(name);
	delay_ms(100);
}

void LED_On(enum LED_Name name)
{
	switch(name)
	{
	case SYS:
		GPIO_ResetBits(GPIOC,GPIO_Pin_13);
		break;
	case COM:
		GPIO_ResetBits(GPIOC,GPIO_Pin_14);
		break;
	}
}

void LED_Off(enum LED_Name name)
{
	switch(name)
	{
	case SYS:
		GPIO_SetBits(GPIOC,GPIO_Pin_13);
		break;
	case COM:
		GPIO_SetBits(GPIOC,GPIO_Pin_14);
		break;
	}
}
