/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                           ���ߺ���                                                                                                */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

#ifndef TOOLS_H_
#define TOOLS_H_

#include "stm32f4XX.h"

enum SystemMode
{
	Receiver,
	Master
};

// �¶Ȼ��㺯��
float TemperatureCal(u16 voltage);

void Usart1_Send(char* data);


#endif /* TOOLS_H_ */
