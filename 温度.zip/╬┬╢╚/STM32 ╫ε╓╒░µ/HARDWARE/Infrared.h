/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                        ����NEC��������                                                                                         */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

#ifndef INFRARED_H_
#define INFRARED_H_

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "LED.h"

/**********************************************************************************************************/
/* �궨�� */
enum PackType
{
	DATAPACK,
	CMDPACK,
	HANDSHAKEPACK
};

enum DeviceType
{
	UpMonitor,
	ReceiveBorad,
	MainBorad
};

#define Send_Buffer_Size 200
#define Receive_Buffer_Size 200

#define DataUnitBitNum 16  // ���ݵ�Ԫ��С 16
#define DataNum 2

#define AllBitNum 96 // 32*3

extern enum DeviceType ThisDeviceType;

/**********************************************************************************************************/
/* ������ */
// ���ݷ��ͻ�����
extern unsigned int Send_Buffer[Send_Buffer_Size];

// ���ݽ��ջ�����
extern unsigned int Receive_Buffer[Receive_Buffer_Size];

/**********************************************************************************************************/
/* ��ʼ������ */
void Infrared_Init(void);

/**********************************************************************************************************/
/* Ӧ�ú��� */
void Infrared_Send(enum DeviceType devType,enum PackType packType,unsigned int data[]);
void Infrared_SendPack(void);
void Infrared_MakeDataPack(enum DeviceType devType,unsigned int data[]);
void Infrared_MakeCmdPack(enum DeviceType devType,unsigned int data[]);
void Infrared_MakeHandPack(enum DeviceType devType,unsigned int data[]);

// ���ռ�⺯��
void Infrared_Receive_Check(void);
// ���պ���
void Infrared_Receive(void);
// ���ݴ�������
void Infrared_HandleData(void);

void Infrared_Unpack(void);

void Infrared_HandleCmd(unsigned int CMD1,unsigned int CMD2);

/**********************************************************************************************************/
/* �ڲ��������� */
// �źŷ���
void Infrared_SendStartSignal(void);
void Infrared_SendLogicHigh(void);
void Infrared_SendLogicLow(void);
void Infrared_SendEndSignal(void);
// 38 kHz�ز�
void Infrared_CarrierWave(unsigned int time);
// ���뺯��
void Infrared_HandleData(void);
// �������ݰ�
void Infrared_SendFrame(unsigned int data[]);

/**********************************************************************************************************/
/* ���Դ��� */
// ���Ͳ��Ժ���
void Infrared_SendTest(void);

#endif /* INFRARED_H_ */

