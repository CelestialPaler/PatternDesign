/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                        ����NEC��������                                                                                         */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "Infrared.h"

/**********************************************************************************************************/
/* ������ */
// ���ݷ��ͻ�����
unsigned int Send_Buffer[Send_Buffer_Size];

// ���ݽ��ջ�����
unsigned int Receive_Buffer[Receive_Buffer_Size];

unsigned int DataPack_Buffer[32];

// ��ַ��
unsigned int UM[]={0,1,1,0,0,1};
unsigned int RB[]={1,0,1,0,1,0};
unsigned int MB[]={1,1,1,0,0,0};

// ������
unsigned int DATA[]={0,1,0,1};
unsigned int CMD[]={1,1,0,0};
unsigned int HAND[]={0,1,1,0};

unsigned int IRtemper1; 
unsigned int IRtemper2; 
unsigned int IRCmd1;
unsigned int IRCmd2;

enum DeviceType ThisDeviceType = ReceiveBorad;

/**********************************************************************************************************/
/* ��ʼ������ */
void Infrared_Init(void)
{
	// ��ʼ���ź��������
	{
		// ��ʼ���ṹ��
		GPIO_InitTypeDef GPIO_InitStructure;
		// ʹ�����ʱ��
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		// ���г�ʼ��
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
	}
	
	// ��ʼ����ʱ������
	{
		// ��ʼ���ṹ��
		GPIO_InitTypeDef         GPIO_InitStructure;
		TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		NVIC_InitTypeDef         NVIC_InitStructure;
		TIM_ICInitTypeDef  	     TIM5_ICInitStructure;

		// ʹ�����ʱ��
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

		// ���г�ʼ��
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
		GPIO_Init(GPIOA,&GPIO_InitStructure);

		// ���Ź��ܸ���
		GPIO_PinAFConfig(GPIOA,GPIO_PinSource0,GPIO_AF_TIM5);

		// ��ʼ��TIM5
		TIM_TimeBaseStructure.TIM_Prescaler=84-1; // Ԥ��Ƶϵ��
		TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; // ���ϼ���
		TIM_TimeBaseStructure.TIM_Period=0XFFFFFFFF;// �Զ���װ��ֵ
		TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
		TIM_TimeBaseInit(TIM5,&TIM_TimeBaseStructure);

		// ��ʼ��TIM5���벶�����
		TIM5_ICInitStructure.TIM_Channel = TIM_Channel_1; // ѡ������� IC1ӳ�䵽TI1��
		TIM5_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising; // �����ز���
		TIM5_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; // ӳ��
		TIM5_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1; // ����Ƶ
		TIM5_ICInitStructure.TIM_ICFilter = 0x00; // ���˲�
		TIM_ICInit(TIM5, &TIM5_ICInitStructure);

		// �ж�����
		TIM_ITConfig(TIM5,TIM_IT_Update|TIM_IT_CC1,ENABLE);//���������ж� ,����CC1IE�����ж�

		// ��ʱ��ʹ��
		TIM_Cmd(TIM5,ENABLE ); 	//ʹ�ܶ�ʱ��5

		// �ж����ȼ��趨
		NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2; // ��ռ���ȼ�3
		NVIC_InitStructure.NVIC_IRQChannelSubPriority =0; // �����ȼ�3
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; // IRQͨ��ʹ��
		NVIC_Init(&NVIC_InitStructure);
	}
}

/**********************************************************************************************************/
/* Ӧ�ú��� */


unsigned int recievedata[AllBitNum];

void Infrared_Send(enum DeviceType devType,enum PackType packType,unsigned int data[])
{
	switch(packType)
	{
	case DATAPACK:
		Infrared_MakeDataPack(devType,data);
		Infrared_SendPack();
		break;
	case CMDPACK:
		Infrared_MakeCmdPack(devType,data);
		Infrared_SendPack();
		break;
	case HANDSHAKEPACK:
		Infrared_MakeHandPack(devType,data);
		Infrared_SendPack();
		break;
	}
}

void Infrared_MakeDataPack(enum DeviceType devType,unsigned int data[])
{
	int i,j,k;
	unsigned int tempbinary[DataUnitBitNum] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	switch(ThisDeviceType)
	{
	case UpMonitor:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=UM[i];
		break;
	case ReceiveBorad:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=RB[i];
		break;
	case MainBorad:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=MB[i];
		break;
	}

	switch(devType)
	{
	case UpMonitor:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=UM[i-6];
		break;
	case ReceiveBorad:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=RB[i-6];
		break;
	case MainBorad:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=MB[i-6];
		break;
	}

	for(i=12;i<16;++i)
		DataPack_Buffer[i]=DATA[i-12];
	

	for(j=0;j<DataNum;++j)
	{
		k=DataUnitBitNum-1;
		while(data[j])
		{
			tempbinary[k--]=data[j]%2;
			data[j]=data[j]/2;
		}
	for(i=16+j*16;i<32+j*16;i++)
		DataPack_Buffer[i]=tempbinary[i-16];
	}
}

void Infrared_MakeCmdPack(enum DeviceType devType,unsigned int data[])
{
 	int i,j,k;
	unsigned int tempbinary[DataUnitBitNum] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	switch(ThisDeviceType)
	{
	case UpMonitor:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=UM[i];
		break;
	case ReceiveBorad:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=RB[i];
		break;
	case MainBorad:
		for(i=0;i<6;++i)
			DataPack_Buffer[i]=MB[i];
		break;
	}

	switch(devType)
	{
	case UpMonitor:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=UM[i-6];
		break;
	case ReceiveBorad:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=RB[i-6];
		break;
	case MainBorad:
		for(i=6;i<12;++i)
			DataPack_Buffer[i]=MB[i-6];
		break;
	}

	for(i=12;i<16;++i)
		DataPack_Buffer[i]=CMD[i-12];
	

	for(j=0;j<DataNum;++j)
	{
		k=DataUnitBitNum-1;
		while(data[j])
		{
			tempbinary[k--]=data[j]%2;
			data[j]=data[j]/2;
		}
	for(i=16+j*16;i<32+j*16;i++)
		DataPack_Buffer[i]=tempbinary[i-16];
	}
}
	
void Infrared_MakeHandPack(enum DeviceType devType,unsigned int data[])
{}

void Infrared_SendPack()
{
	int i,length=AllBitNum/2;
	Infrared_SendStartSignal();
	for(i=0;i<length;++i)
	{
		if(DataPack_Buffer[i]==0)
			Infrared_SendLogicLow();
		else
			Infrared_SendLogicHigh();
	}
	for(i=0;i<length;++i)
	{
		if(DataPack_Buffer[i]==0)
			Infrared_SendLogicHigh();
		else
			Infrared_SendLogicLow();
	}
	Infrared_SendEndSignal();
}




u8  Capture_State = 0;  //���벶��״̬
u32 Capture_Value;    //���벶��ֵ

long long temp; // ���ݽ��ջ���
long long tempvalue[AllBitNum]; // ���ݽ��ջ�����
unsigned int tempdata[AllBitNum]; // ����֤���ݻ�����
unsigned int tempindex = 0; // ���ݽ��ջ�����ָʾ��

const int Overtime = 1000; // ���ճ�ʱ

int SignalFlag = 0; // ����ź�flag
int ErrorFlag = 0; // ������Чflag

const long long HighSignal = 1680; // �߼����ź������峤�� us
const long long LowSignal = 560; // �߼����ź������峤�� us
const long long Capture_Margin = 200; // ������������
const long long StartSignal = 4500; // �����ź�

// ���ռ�⺯��
void Infrared_Receive_Check(void)
{
	int i;
	if(SignalFlag == 0)
	{
		if(Capture_State&0X80)//���������
		{
			temp=Capture_State&0X3F;
			temp*=0XFFFFFFFF;
			temp+=Capture_Value;
			Capture_State=0;//���ò���
			// ��������ź�
			if(temp>(StartSignal - Capture_Margin)&&temp<(StartSignal + Capture_Margin))
			{
				for(i=0;i<AllBitNum;++i)// ��ջ���
					tempvalue[i] = 0;
				tempindex = 0;
				SignalFlag = 1;// ��⵽�źŵ���
			}
		}
	}
	else
	{
		for(i=0;i<Overtime;++i)// ����ֱ����ʱ
		{
			Infrared_Receive();
		}
	}
}

// ���պ���
void Infrared_Receive(void)
{
	if(tempindex<AllBitNum)// δ������
	{
		if(Capture_State&0X80)// ���������
		{
			temp=Capture_State&0X3F;
			temp*=0XFFFFFFFF;
			temp+=Capture_Value;
			tempvalue[tempindex] = temp;// ������
			Capture_State=0;// ���ò���
			tempindex++;
		}
	}
	else if(tempindex == AllBitNum) // �������
	{
		Infrared_HandleData();// ��������
		tempindex=0;
		SignalFlag = 0;
	}
}

// ���뺯��
void Infrared_HandleData(void)
{
	int i;
	ErrorFlag = 0;

	for(i=0;i<AllBitNum;++i)
	{
		if(ErrorFlag == 0)// ���û�д���
		{
			if(tempvalue[i]>(HighSignal - Capture_Margin)&&tempvalue[i]<(HighSignal + Capture_Margin))
				tempdata[i] = 1;
			else if(tempvalue[i]>(LowSignal - Capture_Margin)&&tempvalue[i]<(LowSignal + Capture_Margin))
				tempdata[i] = 0;
			else
			{
				ErrorFlag = 1;
				break;
			}
		}
	}

	
	for(i=0;i<AllBitNum/2;++i)
	{
		if(ErrorFlag == 0)
		{
			if(tempdata[i]!=tempdata[i+AllBitNum/2])
				recievedata[i] = tempdata[i];
			else
			{
				ErrorFlag = 1;
				break;
			}
		}
	}
	if(ErrorFlag == 0)
	{/*
		printf("Recieved : ");
		for(i=0;i<AllBitNum/2;++i)
			printf("%d",recievedata[i]);
		printf("\r\n");
		*/
		Infrared_Unpack();
	}
	else
	{
		printf("ERROR!");
		ErrorFlag = 0;
	}
}

unsigned int tempfuc(int a)
{
	int i,temp=1;
	for(i=0;i<a;++i)
		temp=temp*2;
	return temp;
}

// ͨ��ģʽ
extern unsigned int comFlag;
extern float temperUpLimit;
extern float temperLowLimit;
extern float Kp;
extern float Ki;
extern float Kd;
extern float temper1;
extern float temper1EKF;
extern float temper2;
extern float temper2EKF;

void Infrared_Unpack(void)
{
	int i;
	IRtemper1 = 0;
	IRtemper2 = 0;
	IRCmd1 = 0;
	IRCmd2 = 0;
	if(recievedata[12]==0)// DATA
	{
		for(i=0;i<16;++i)
			IRtemper1+=recievedata[i+16]*tempfuc(15-i);
		for(i=0;i<16;++i)
			IRtemper2+=recievedata[i+32]*tempfuc(15-i);
		printf("<<<,MB,UM,DATA,%f,%f,%f,%f,%f,%d,%f,%d,%f,>>>\r\n",temperUpLimit,temperLowLimit,Kp,Ki,Kd,IRtemper1,temper1EKF,IRtemper2,temper1EKF);
	}
	else if(recievedata[12]==1)// CMD
	{
		for(i=0;i<16;++i)
			IRCmd1+=recievedata[i+16]*tempfuc(15-i);
		for(i=0;i<16;++i)
			IRCmd2+=recievedata[i+32]*tempfuc(15-i);
		Infrared_HandleCmd(IRCmd1,IRCmd2);
	}
}

void Infrared_HandleCmd(unsigned int CMD1,unsigned int CMD2)
{
	switch(CMD1)
	{
		case 1000:
			if(CMD2==1000)
				comFlag = 1;
			else if(CMD2==2000)
				comFlag = 2;
			break;
		case 2000:
			temperUpLimit = CMD2;
			break;
		case 3000:
			temperLowLimit = CMD2;
			break;
	}
}

// ��ʱ��5�жϷ�����
void TIM5_IRQHandler(void)
{
	if((Capture_State&0X80)==0)
	{
		if(TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET)
		{
			if(Capture_State&0X40)
			{
				if((Capture_State&0X3F)==0X3F)
				{
					Capture_State|=0X80;
					Capture_Value=0XFFFFFFFF;
				}
				else Capture_State++;
			}
		}
		if(TIM_GetITStatus(TIM5, TIM_IT_CC1) != RESET)
		{
			if(Capture_State&0X40)
			{
				Capture_State|=0X80;
				Capture_Value=TIM_GetCapture1(TIM5);
				TIM_OC1PolarityConfig(TIM5,TIM_ICPolarity_Rising);
			}
			else
			{
				Capture_State=0;
				Capture_Value=0;
				Capture_State|=0X40;
				TIM_Cmd(TIM5,DISABLE );
				TIM_SetCounter(TIM5,0);
				TIM_OC1PolarityConfig(TIM5,TIM_ICPolarity_Falling);
				TIM_Cmd(TIM5,ENABLE );
			}
		}
	}
	TIM_ClearITPendingBit(TIM5, TIM_IT_CC1|TIM_IT_Update);
}



/**********************************************************************************************************/
/* �ڲ��������� */
// �źŷ���
// ���������ź�
void Infrared_SendStartSignal(void)
{
	Infrared_CarrierWave(346);// 9000us
	delay_us(4500);
}

// �����߼���
void Infrared_SendLogicHigh(void)
{
	Infrared_CarrierWave(21);// 560us
	delay_us(1680);
}

// �����߼���
void Infrared_SendLogicLow(void)
{
	Infrared_CarrierWave(21);// 560us
	delay_us(560);
}

// ���ͽ����ź�
void Infrared_SendEndSignal(void)
{
	Infrared_CarrierWave(346);// 9000us
	delay_us(560);
}

// 38 kHz�ز�
const unsigned int CW_Frequence = 13; // �ز�Ƶ���趨
void Infrared_CarrierWave(unsigned int time)
{
	for(;time>0;--time)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_5);
		delay_us(CW_Frequence);
		GPIO_ResetBits(GPIOA,GPIO_Pin_5);
		delay_us(CW_Frequence);
	}
}





