/**********************************************************************************************************/
/*                                      ����PWM�¶ȿ���ϵͳ                                                                                      */
/*                                          ͨ��Э���                                                                                              */
/*                                         ��ʦ��а�Ƽ�                                                                                             */
/*                                     Copyright 2015-2017                                                */
/*                               ������� : www.tianshicangxie.com                                         */
/**********************************************************************************************************/

/**********************************************************************************************************/
/* ͷ�ļ� */
#include "Pack.h"

/**********************************************************************************************************/
/* ȫ�ֱ��� */
char Begin[] = "<<<";
char End[] = ">>>";
char UM[] = "UM";
char RB[] = "RB";
char MB[] = "MB";
char DATA[] = "DT";
char CMD[] = "CM";

// �������
char Buffer[1000];

/**********************************************************************************************************/
/* Ӧ�ú��� */
// ���Ͱ�����
void SendPack()
{
	MakePack();
	Usart1_Send(Buffer);
	ClearPack();
}

/**********************************************************************************************************/
/* �ڲ��������� */
// ������� ���Ӱ���Ϣ
void Pack_AddInfo(char* data)
{
	strcat(Buffer,data);
	strcat(Buffer,",");
}
// ������� ���Ӱ�����
void Pack_AddData(float data)
{
	char temp[100];
	sprintf(temp,"%g",data);
	strcat(Buffer,temp);
	strcat(Buffer,",");
}
// ������� ���Ӱ���ʼ��־
void Pack_AddBegin()
{
	strcat(Buffer,Begin);
	strcat(Buffer,",");
}
// ������� ���Ӱ�������־
void Pack_AddEnd()
{
	strcat(Buffer,End);
	strcat(Buffer,"\r\n");
}

unsigned int counter = 0;
float tempqwewq;
// �������
void MakePack()
{
	srand(counter);
	tempqwewq = (float)rand()/RAND_MAX;
	Pack_AddBegin();
	Pack_AddInfo(MB);
	Pack_AddInfo(UM);
	Pack_AddInfo(DATA);
	Pack_AddData(temperUpLimit);
	Pack_AddData(temperLowLimit);
	Pack_AddData(Kp);
	Pack_AddData(Ki);
	Pack_AddData(Kd);
	Pack_AddData(temp1+tempqwewq);
	Pack_AddData(temp1EKF+tempqwewq);
	Pack_AddData(temp2+tempqwewq);
	Pack_AddData(temp2EKF+tempqwewq);
	Pack_AddData(tempqwewq);
	Pack_AddEnd();
	counter++;
}
// ��հ����庯��
void ClearPack()
{
	memset(Buffer,0,1000);
}



