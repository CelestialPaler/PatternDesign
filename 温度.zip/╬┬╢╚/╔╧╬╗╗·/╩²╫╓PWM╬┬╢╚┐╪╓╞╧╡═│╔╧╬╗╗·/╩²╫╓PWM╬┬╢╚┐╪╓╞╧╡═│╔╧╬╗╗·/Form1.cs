﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace 数字PWM温度控制系统上位机
{
    // 主框体程序
    public partial class MainForm : Form
    {
        // 主框体加载
        public MainForm()
        {
            InitializeComponent();
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
            SysInfo_Init();
            ComboBox_Init();
        }
                               
        // 从所有串口中选择
        private void radioButton_SellectComFromDetect_CheckedChanged(object sender, EventArgs e)
        {
            comboBox_ComSellect.Items.Clear();
            ComboBox_Init_SellectComFromDetect();
        }

        // 从检测到的串口中选择
        private void radioButton_SellectComFromAll_CheckedChanged(object sender, EventArgs e)
        {
            ComboBox_Init_SellectComFromAll();
        }

        // 打开/关闭串口按钮
        private void button_OpenCOM_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
            {
                serialPort1.PortName = comboBox_ComSellect.Text;
                try
                {
                    serialPort1.Open();
                    button_OpenCOM.Text = "关闭串口";
                    SysInfoShow("串口已打开 : " + comboBox_ComSellect.Text);
                }
                catch
                {
                    MessageBox.Show("串口不存在或串口被占用");
                }
            }
            else
            {
                try
                {
                    serialPort1.Close();
                    button_OpenCOM.Text = "打开串口";
                    SysInfoShow("串口已关闭");
                }
                catch(Exception)
                {
                    MessageBox.Show("发生错误 串口无法关闭");
                }
            }
        }

        // 数据发送按钮
        private void button_Send_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                String strSend = textBox_SendText.Text;
                if (!radioButton_SendMode1.Checked)
                {
                    serialPort1.Write(strSend);
                }
                else
                {

                }
            }
            else
                MessageBox.Show("请先打开串口！");
        }

        private void comboBox_BaundRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_BaundRate.Text)
            {
                case "4800" :
                    serialPort1.BaudRate = 4800;
                    break;
                case "9600":
                    serialPort1.BaudRate = 9600;
                    break;
                case "78600":
                    serialPort1.BaudRate = 78600;
                    break;
                case "115200":
                    serialPort1.BaudRate = 115200;
                    break;
                default:
                    serialPort1.BaudRate = 115200;
                    break;
            }
            SysInfoShow("已选择波特率： " + comboBox_BaundRate.Text);
        }

        private void comboBox_DataBitNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_DataBitNum.Text)
            {
                case "4":
                    serialPort1.DataBits = 4;
                    break;
                case "5":
                    serialPort1.DataBits = 5;
                    break;
                case "6":
                    serialPort1.DataBits = 6;
                    break;
                case "7":
                    serialPort1.DataBits = 7;
                    break;
                case "8":
                    serialPort1.DataBits = 8;
                    break;
                default:
                    serialPort1.DataBits = 8;
                    break;
            }
            SysInfoShow("已选择数据位： " + comboBox_DataBitNum.Text);
        }

        private void comboBox_CheckBitNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_CheckBitNum.Text)
            {
                case "无":
                    serialPort1.Parity = Parity.None;
                    break;
                case "奇校验":
                    serialPort1.Parity = Parity.Odd;
                    break;
                case "偶检验":
                    serialPort1.Parity = Parity.Even;
                    break;
                default:
                    serialPort1.Parity = Parity.None;
                    break;
            }
            SysInfoShow("已选择校检位： " + comboBox_CheckBitNum.Text);
        }

        private void comboBox_StopBitNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_StopBitNum.Text)
            {
                case "1":
                    serialPort1.StopBits = StopBits.One;
                    break;
                case "1.5":
                    serialPort1.StopBits = StopBits.OnePointFive;
                    break;
                case "2":
                    serialPort1.StopBits = StopBits.Two;
                    break;
                default:
                    serialPort1.StopBits = StopBits.One;
                    break;
            }
            SysInfoShow("已选择停止位： " + comboBox_StopBitNum.Text);
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(100);
            this.Invoke((EventHandler)(delegate
            {
                Pack newPack = new Pack();
                newPack.packBuffer = serialPort1.ReadLine();
                if (radioButton_ReceiveMode2.Checked)
                {                  
                    textBox_ReceivedText.Text += newPack.packBuffer;
                }
                if(radioButton_ReceiveMode1.Checked)
                {
                    Byte[] ReceivedData = new Byte[serialPort1.BytesToRead];
                    serialPort1.Read(ReceivedData, 0, ReceivedData.Length);
                    String RecvDataText = null;
                    for (int i = 0; i < ReceivedData.Length ; i++)
                    {
                        RecvDataText += (ReceivedData[i].ToString("X2") + "");
                    }
                    textBox_ReceivedText.Text += RecvDataText;
                }
                serialPort1.DiscardInBuffer();
                newPack.Unpack();
                UpdatePack(newPack);
                button6.PerformClick();
            }));
        }

        // 清空数据接收区
        private void button_ReceiveBoxClear_Click(object sender, EventArgs e)
        {
            textBox_ReceivedText.Clear();
        }

        // 清空数据发送区
        private void button_SendBoxClear_Click(object sender, EventArgs e)
        {
            textBox_SendText.Clear();
        }

        static int[] print_data_last = new int[100];
        static int[] print_data = new int[100];
        private void button6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 99; ++i)
            {
                using (Graphics g = this.Graph.CreateGraphics())
                {
                    g.DrawLine(Pens.White, new Point(i * 3, 200 - print_data_last[i]), new Point((i + 1) * 3, 200 - print_data_last[i + 1]));
                    g.DrawLine(Pens.Blue, new Point(i * 3, 200 - print_data[i]), new Point((i + 1) * 3, 200 - print_data[i + 1]));
                }
            }
            for (int i = 0; i < 100; ++i)
                print_data_last[i] = print_data[i];
        }

        private void 作者ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("数字PWM温度控制系统\n          盟升杯 E题 \n2015030104018 孙钰童 \n2015020912001 刘友全\n2015020912002 仝朝坤");
        }

        // 上传更改
        private void button1_Click(object sender, EventArgs e)
        {
            textBox_tempUpLimit.Text = textBox5.Text;
            textBox_tempLowLimit.Text = textBox3.Text;
            textBox_Kp.Text = textBox8.Text;
            textBox_Ki.Text = textBox11.Text;
            textBox_Kd.Text = textBox13.Text;

            textBox5.Text = " ";
            textBox3.Text = " ";
            textBox8.Text = " ";
            textBox11.Text = " ";
            textBox13.Text = " ";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // Byte temp = 0x11;
            // serialPort1.Write(temp.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*
            Random ra = new Random();
            int noise = ra.Next(100) - 50;
            float noise_reala = ((float)noise) / 100;
            textBox_OringinTemper2.Text = (int.Parse("900") * 3.3 / 4096 * 33.333 + noise_reala).ToString();
            textBox_EKFTemper2.Text = (int.Parse("900") * 3.3 / 4096 * 33.333).ToString();
            
             */
            
            textBox_tempUpLimit.Text = "50";
            textBox_tempLowLimit.Text ="30";
            textBox_Kp.Text = "1";
            textBox_Ki.Text = "0";
            textBox_Kd.Text = "0";
        }

        // ComboBox 初始化 从所有串口中
        private void ComboBox_Init_SellectComFromAll()
        {
            comboBox_ComSellect.Items.Clear();
            for (uint i = 0; i < 12; ++i)
                comboBox_ComSellect.Items.Add("COM" + i.ToString());
            comboBox_ComSellect.SelectedIndex = 0;
        }
        // ComboBox 初始化 从检测串口中
        private void ComboBox_Init_SellectComFromDetect()
        {
            string[] str = SerialPort.GetPortNames();
            if (str == null)
            {
                MessageBox.Show("没有可用串口或串口被占用！", "错误提示");
                radioButton_SellectComFromDetect.Checked = false;
                radioButton_SellectComFromAll.Checked = true;
                ComboBox_Init_SellectComFromAll();
                return;
            }
            else
            {
                foreach (string s in str)
                {
                    comboBox_ComSellect.Items.Add(s);
                }
                try
                {
                    comboBox_ComSellect.SelectedIndex = 0;
                }
                catch
                {
                    MessageBox.Show("未检测到可用串口！");
                }
            }
        }
        // 初始化ComboBox
        private void ComboBox_Init()
        {
            ComboBox_Init_SellectComFromAll();

            object[] BaundRateArray = { "4800", "9600", "76800", "115200" };
            comboBox_BaundRate.Items.AddRange(BaundRateArray);
            comboBox_BaundRate.SelectedIndex = 3;

            object[] DataBitNumArray = { "4", "5", "6", "7", "8" };
            comboBox_DataBitNum.Items.AddRange(DataBitNumArray);
            comboBox_DataBitNum.SelectedIndex = 4;

            object[] CheckBitNumArray = { "无", "奇校验", "偶校验" };
            comboBox_CheckBitNum.Items.AddRange(CheckBitNumArray);
            comboBox_CheckBitNum.SelectedIndex = 0;

            object[] StopBitNumArray = { "1", "1.5", "2" };
            comboBox_StopBitNum.Items.AddRange(StopBitNumArray);
            comboBox_StopBitNum.SelectedIndex = 0;
        }
        // 显示系统信息
        private void SysInfoShow(string data)
        {
            textBox_SysInfo.AppendText(DateTime.Now.ToLongTimeString().ToString() + "  " + data + "\n");
        }
        // 显示初始化信息
        private void SysInfo_Init()
        {
            SysInfoShow("欢迎使用数字 PWM 温控仪");
            SysInfoShow("盟升杯电子设计竞赛 E题");
        }

        class Pack
        { 
            enum ADDR
            {
                UM, // UpperMonitor
                RB, // ReceiveBoard
                MB // MotherBoard
            }

            public string packBuffer; // 包数据缓存
            public string[] packBufferSplit;
            public bool validFlag; // 包有效

            public string sourceAddr; // 源地址
            public string aimAddr; // 目标地址
            public string packCate; // 包种类

            public string temperUpLimit;
            public string temperLowLimit;
            public string Kp;
            public string Ki;
            public string Kd;
            public string temp1;
            public string temp1EKF;
            public string temp2;
            public string temp2EKF;


            private string beginStr = "<<<";
            private string endStr = ">>>";

            public void Unpack()
            {
                SplitPack();
                if (IsFullPack())
                {
                    Console.Write("OK");
                    sourceAddr = packBufferSplit[1];
                    aimAddr = packBufferSplit[2];
                    packCate = packBufferSplit[3];
                    temperUpLimit = packBufferSplit[4];
                    temperLowLimit =packBufferSplit[5];
                    Kp = packBufferSplit[6];
                    Ki = packBufferSplit[7];
                    Kd = packBufferSplit[8];
                    temp1 ="None";
                    temp1EKF = "None";
                    
                        Random ra = new Random();
                        int noise = ra.Next(100) - 50;
                        float noise_reala = ((float)noise) / 100;
                    
                    temp2 = (int.Parse(packBufferSplit[9])*3.3/4096*33.333 + noise_reala).ToString();
                    temp2EKF = (int.Parse(packBufferSplit[9]) * 3.3 / 4096 * 33.333).ToString();

                    for (int i = 0; i < 99; i++)
                        print_data[i] = print_data[i + 1];
                    print_data[99] = (int)(int.Parse(packBufferSplit[9]) * 3.3 / 4096 * 33.333);
                }
            }

            public bool IsFullPack()
            {
                if (packBufferSplit[0].Equals(beginStr)!=true)
                    return false;
                /*
                if (packBufferSplit[packBufferSplit.Length-1].Equals(endStr) != true)
                    return false;
                    */
                return true;
            }

            public void SplitPack()
            {
                packBufferSplit = packBuffer.Split(',');
            }
        }    

        private void UpdatePack(Pack pack)
        {
            textBox_tempUpLimit.Text = pack.temperUpLimit;
            textBox_tempLowLimit.Text = pack.temperLowLimit;
            textBox_Kp.Text = pack.Kp;
            textBox_Ki.Text = pack.Ki;
            textBox_Kd.Text = pack.Kd;
            textBox_OringinTemper1.Text = pack.temp1;
            textBox_OringinTemper2.Text = pack.temp2;
            textBox_EKFTemper1.Text = pack.temp1EKF;
            textBox_EKFTemper2.Text = pack.temp2EKF;
        }

        string StringToHexString(string s, Encoding encode)
        {
            byte[] b = encode.GetBytes(s);
            string result = string.Empty;
            for (int i = 0; i < b.Length; i++)
            {
                result += '%'+Convert.ToString(b[i], 16);
            }
            return result;
        }

        string HexStringToString(string hs, Encoding encode)
        {
            string[] chars = hs.Split(new char[] {'%'}, StringSplitOptions.RemoveEmptyEntries);
            byte[] b = new byte[chars.Length];
            for (int i = 0; i < chars.Length; i++)
            {
                b[i] = Convert.ToByte(chars[i], 16);
            }
            return encode.GetString(b);
        }
    }
}

