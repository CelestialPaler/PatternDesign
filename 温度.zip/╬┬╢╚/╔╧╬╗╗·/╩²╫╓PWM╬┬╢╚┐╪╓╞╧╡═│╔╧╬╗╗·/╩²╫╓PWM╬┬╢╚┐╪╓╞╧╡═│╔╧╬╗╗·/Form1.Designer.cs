﻿namespace 数字PWM温度控制系统上位机
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox_StopBitNum = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox_CheckBitNum = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_DataBitNum = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_BaundRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_OpenCOM = new System.Windows.Forms.Button();
            this.radioButton_SellectComFromDetect = new System.Windows.Forms.RadioButton();
            this.radioButton_SellectComFromAll = new System.Windows.Forms.RadioButton();
            this.comboBox_ComSellect = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.菜单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.作者ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_AutoSend = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton_SendMode2 = new System.Windows.Forms.RadioButton();
            this.radioButton_SendMode1 = new System.Windows.Forms.RadioButton();
            this.button_Send = new System.Windows.Forms.Button();
            this.button_SendBoxClear = new System.Windows.Forms.Button();
            this.textBox_SendText = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_ReceivedText = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButton_ReceiveMode2 = new System.Windows.Forms.RadioButton();
            this.radioButton_ReceiveMode1 = new System.Windows.Forms.RadioButton();
            this.button_ReceiveBoxClear = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox_Kd = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox_Ki = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox_Kp = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.wendu = new System.Windows.Forms.GroupBox();
            this.textBox_tempUpLimit = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_tempLowLimit = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Graph = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox_SysInfo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_EKFTemper2 = new System.Windows.Forms.TextBox();
            this.textBox_EKFTemper1 = new System.Windows.Forms.TextBox();
            this.textBox_OringinTemper2 = new System.Windows.Forms.TextBox();
            this.textBox_OringinTemper1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.wendu.SuspendLayout();
            this.panel4.SuspendLayout();
            this.Graph.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(9, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "串口设置";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.comboBox_StopBitNum);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.comboBox_CheckBitNum);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.comboBox_DataBitNum);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.comboBox_BaundRate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button_OpenCOM);
            this.panel1.Controls.Add(this.radioButton_SellectComFromDetect);
            this.panel1.Controls.Add(this.radioButton_SellectComFromAll);
            this.panel1.Controls.Add(this.comboBox_ComSellect);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel1.Location = new System.Drawing.Point(9, 53);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(388, 140);
            this.panel1.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 106);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "停止位";
            // 
            // comboBox_StopBitNum
            // 
            this.comboBox_StopBitNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_StopBitNum.FormattingEnabled = true;
            this.comboBox_StopBitNum.Location = new System.Drawing.Point(53, 104);
            this.comboBox_StopBitNum.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_StopBitNum.Name = "comboBox_StopBitNum";
            this.comboBox_StopBitNum.Size = new System.Drawing.Size(128, 20);
            this.comboBox_StopBitNum.TabIndex = 12;
            this.comboBox_StopBitNum.SelectedIndexChanged += new System.EventHandler(this.comboBox_StopBitNum_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 83);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 11;
            this.label13.Text = "校检位";
            // 
            // comboBox_CheckBitNum
            // 
            this.comboBox_CheckBitNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_CheckBitNum.FormattingEnabled = true;
            this.comboBox_CheckBitNum.Location = new System.Drawing.Point(53, 81);
            this.comboBox_CheckBitNum.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_CheckBitNum.Name = "comboBox_CheckBitNum";
            this.comboBox_CheckBitNum.Size = new System.Drawing.Size(128, 20);
            this.comboBox_CheckBitNum.TabIndex = 10;
            this.comboBox_CheckBitNum.SelectedIndexChanged += new System.EventHandler(this.comboBox_CheckBitNum_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 60);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 9;
            this.label12.Text = "数据位";
            // 
            // comboBox_DataBitNum
            // 
            this.comboBox_DataBitNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_DataBitNum.FormattingEnabled = true;
            this.comboBox_DataBitNum.Location = new System.Drawing.Point(53, 58);
            this.comboBox_DataBitNum.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_DataBitNum.Name = "comboBox_DataBitNum";
            this.comboBox_DataBitNum.Size = new System.Drawing.Size(128, 20);
            this.comboBox_DataBitNum.TabIndex = 8;
            this.comboBox_DataBitNum.SelectedIndexChanged += new System.EventHandler(this.comboBox_DataBitNum_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 37);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 7;
            this.label11.Text = "波特率";
            // 
            // comboBox_BaundRate
            // 
            this.comboBox_BaundRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_BaundRate.FormattingEnabled = true;
            this.comboBox_BaundRate.Location = new System.Drawing.Point(53, 34);
            this.comboBox_BaundRate.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_BaundRate.Name = "comboBox_BaundRate";
            this.comboBox_BaundRate.Size = new System.Drawing.Size(128, 20);
            this.comboBox_BaundRate.TabIndex = 6;
            this.comboBox_BaundRate.SelectedIndexChanged += new System.EventHandler(this.comboBox_BaundRate_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "串口号";
            // 
            // button_OpenCOM
            // 
            this.button_OpenCOM.Location = new System.Drawing.Point(280, 96);
            this.button_OpenCOM.Margin = new System.Windows.Forms.Padding(2);
            this.button_OpenCOM.Name = "button_OpenCOM";
            this.button_OpenCOM.Size = new System.Drawing.Size(97, 33);
            this.button_OpenCOM.TabIndex = 4;
            this.button_OpenCOM.Text = "打开串口";
            this.button_OpenCOM.UseVisualStyleBackColor = true;
            this.button_OpenCOM.Click += new System.EventHandler(this.button_OpenCOM_Click);
            // 
            // radioButton_SellectComFromDetect
            // 
            this.radioButton_SellectComFromDetect.AutoSize = true;
            this.radioButton_SellectComFromDetect.Location = new System.Drawing.Point(266, 34);
            this.radioButton_SellectComFromDetect.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_SellectComFromDetect.Name = "radioButton_SellectComFromDetect";
            this.radioButton_SellectComFromDetect.Size = new System.Drawing.Size(119, 16);
            this.radioButton_SellectComFromDetect.TabIndex = 3;
            this.radioButton_SellectComFromDetect.Text = "自动检测可用串口";
            this.radioButton_SellectComFromDetect.UseVisualStyleBackColor = true;
            this.radioButton_SellectComFromDetect.CheckedChanged += new System.EventHandler(this.radioButton_SellectComFromDetect_CheckedChanged);
            // 
            // radioButton_SellectComFromAll
            // 
            this.radioButton_SellectComFromAll.AutoSize = true;
            this.radioButton_SellectComFromAll.Checked = true;
            this.radioButton_SellectComFromAll.Location = new System.Drawing.Point(266, 10);
            this.radioButton_SellectComFromAll.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_SellectComFromAll.Name = "radioButton_SellectComFromAll";
            this.radioButton_SellectComFromAll.Size = new System.Drawing.Size(119, 16);
            this.radioButton_SellectComFromAll.TabIndex = 2;
            this.radioButton_SellectComFromAll.TabStop = true;
            this.radioButton_SellectComFromAll.Text = "从所有串口中选择";
            this.radioButton_SellectComFromAll.UseVisualStyleBackColor = true;
            this.radioButton_SellectComFromAll.CheckedChanged += new System.EventHandler(this.radioButton_SellectComFromAll_CheckedChanged);
            // 
            // comboBox_ComSellect
            // 
            this.comboBox_ComSellect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ComSellect.FormattingEnabled = true;
            this.comboBox_ComSellect.Location = new System.Drawing.Point(53, 11);
            this.comboBox_ComSellect.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_ComSellect.Name = "comboBox_ComSellect";
            this.comboBox_ComSellect.Size = new System.Drawing.Size(128, 20);
            this.comboBox_ComSellect.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单ToolStripMenuItem,
            this.关于ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1056, 25);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 菜单ToolStripMenuItem
            // 
            this.菜单ToolStripMenuItem.Name = "菜单ToolStripMenuItem";
            this.菜单ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.菜单ToolStripMenuItem.Text = "菜单";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.作者ToolStripMenuItem});
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.关于ToolStripMenuItem.Text = "关于";
            // 
            // 作者ToolStripMenuItem
            // 
            this.作者ToolStripMenuItem.Name = "作者ToolStripMenuItem";
            this.作者ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.作者ToolStripMenuItem.Text = "作者";
            this.作者ToolStripMenuItem.Click += new System.EventHandler(this.作者ToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(9, 200);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "数据收发调试";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(9, 222);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(388, 420);
            this.panel2.TabIndex = 10;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button_AutoSend);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.button_Send);
            this.groupBox3.Controls.Add(this.button_SendBoxClear);
            this.groupBox3.Controls.Add(this.textBox_SendText);
            this.groupBox3.Location = new System.Drawing.Point(6, 14);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(378, 150);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "数据发送区";
            // 
            // button_AutoSend
            // 
            this.button_AutoSend.Location = new System.Drawing.Point(274, 19);
            this.button_AutoSend.Margin = new System.Windows.Forms.Padding(2);
            this.button_AutoSend.Name = "button_AutoSend";
            this.button_AutoSend.Size = new System.Drawing.Size(97, 33);
            this.button_AutoSend.TabIndex = 15;
            this.button_AutoSend.Text = "自动连续发送";
            this.button_AutoSend.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton_SendMode2);
            this.groupBox4.Controls.Add(this.radioButton_SendMode1);
            this.groupBox4.Location = new System.Drawing.Point(5, 99);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(264, 46);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "数据发送方式";
            // 
            // radioButton_SendMode2
            // 
            this.radioButton_SendMode2.AutoSize = true;
            this.radioButton_SendMode2.Location = new System.Drawing.Point(125, 19);
            this.radioButton_SendMode2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_SendMode2.Name = "radioButton_SendMode2";
            this.radioButton_SendMode2.Size = new System.Drawing.Size(59, 16);
            this.radioButton_SendMode2.TabIndex = 12;
            this.radioButton_SendMode2.Text = "字符串";
            this.radioButton_SendMode2.UseVisualStyleBackColor = true;
            // 
            // radioButton_SendMode1
            // 
            this.radioButton_SendMode1.AutoSize = true;
            this.radioButton_SendMode1.Checked = true;
            this.radioButton_SendMode1.Location = new System.Drawing.Point(16, 19);
            this.radioButton_SendMode1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_SendMode1.Name = "radioButton_SendMode1";
            this.radioButton_SendMode1.Size = new System.Drawing.Size(71, 16);
            this.radioButton_SendMode1.TabIndex = 11;
            this.radioButton_SendMode1.TabStop = true;
            this.radioButton_SendMode1.Text = "十六进制";
            this.radioButton_SendMode1.UseVisualStyleBackColor = true;
            // 
            // button_Send
            // 
            this.button_Send.Location = new System.Drawing.Point(274, 110);
            this.button_Send.Margin = new System.Windows.Forms.Padding(2);
            this.button_Send.Name = "button_Send";
            this.button_Send.Size = new System.Drawing.Size(97, 33);
            this.button_Send.TabIndex = 8;
            this.button_Send.Text = "发送";
            this.button_Send.UseVisualStyleBackColor = true;
            this.button_Send.Click += new System.EventHandler(this.button_Send_Click);
            // 
            // button_SendBoxClear
            // 
            this.button_SendBoxClear.Location = new System.Drawing.Point(274, 63);
            this.button_SendBoxClear.Margin = new System.Windows.Forms.Padding(2);
            this.button_SendBoxClear.Name = "button_SendBoxClear";
            this.button_SendBoxClear.Size = new System.Drawing.Size(97, 33);
            this.button_SendBoxClear.TabIndex = 7;
            this.button_SendBoxClear.Text = "清空";
            this.button_SendBoxClear.UseVisualStyleBackColor = true;
            this.button_SendBoxClear.Click += new System.EventHandler(this.button_SendBoxClear_Click);
            // 
            // textBox_SendText
            // 
            this.textBox_SendText.Location = new System.Drawing.Point(7, 17);
            this.textBox_SendText.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_SendText.Multiline = true;
            this.textBox_SendText.Name = "textBox_SendText";
            this.textBox_SendText.Size = new System.Drawing.Size(264, 78);
            this.textBox_SendText.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox_ReceivedText);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.button_ReceiveBoxClear);
            this.groupBox1.Location = new System.Drawing.Point(6, 169);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(378, 241);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据接收区";
            // 
            // textBox_ReceivedText
            // 
            this.textBox_ReceivedText.Location = new System.Drawing.Point(5, 19);
            this.textBox_ReceivedText.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ReceivedText.Multiline = true;
            this.textBox_ReceivedText.Name = "textBox_ReceivedText";
            this.textBox_ReceivedText.ReadOnly = true;
            this.textBox_ReceivedText.Size = new System.Drawing.Size(366, 165);
            this.textBox_ReceivedText.TabIndex = 13;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButton_ReceiveMode2);
            this.groupBox5.Controls.Add(this.radioButton_ReceiveMode1);
            this.groupBox5.Location = new System.Drawing.Point(8, 188);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(262, 48);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "数据接收方式";
            // 
            // radioButton_ReceiveMode2
            // 
            this.radioButton_ReceiveMode2.AutoSize = true;
            this.radioButton_ReceiveMode2.Location = new System.Drawing.Point(123, 19);
            this.radioButton_ReceiveMode2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_ReceiveMode2.Name = "radioButton_ReceiveMode2";
            this.radioButton_ReceiveMode2.Size = new System.Drawing.Size(59, 16);
            this.radioButton_ReceiveMode2.TabIndex = 8;
            this.radioButton_ReceiveMode2.Text = "字符串";
            this.radioButton_ReceiveMode2.UseVisualStyleBackColor = true;
            // 
            // radioButton_ReceiveMode1
            // 
            this.radioButton_ReceiveMode1.AutoSize = true;
            this.radioButton_ReceiveMode1.Checked = true;
            this.radioButton_ReceiveMode1.Location = new System.Drawing.Point(14, 19);
            this.radioButton_ReceiveMode1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton_ReceiveMode1.Name = "radioButton_ReceiveMode1";
            this.radioButton_ReceiveMode1.Size = new System.Drawing.Size(71, 16);
            this.radioButton_ReceiveMode1.TabIndex = 7;
            this.radioButton_ReceiveMode1.TabStop = true;
            this.radioButton_ReceiveMode1.Text = "十六进制";
            this.radioButton_ReceiveMode1.UseVisualStyleBackColor = true;
            // 
            // button_ReceiveBoxClear
            // 
            this.button_ReceiveBoxClear.Location = new System.Drawing.Point(274, 198);
            this.button_ReceiveBoxClear.Margin = new System.Windows.Forms.Padding(2);
            this.button_ReceiveBoxClear.Name = "button_ReceiveBoxClear";
            this.button_ReceiveBoxClear.Size = new System.Drawing.Size(97, 33);
            this.button_ReceiveBoxClear.TabIndex = 6;
            this.button_ReceiveBoxClear.Text = "清空";
            this.button_ReceiveBoxClear.UseVisualStyleBackColor = true;
            this.button_ReceiveBoxClear.Click += new System.EventHandler(this.button_ReceiveBoxClear_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(406, 30);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "参数设置";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.groupBox2);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.groupBox6);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.wendu);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Location = new System.Drawing.Point(410, 53);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(282, 292);
            this.panel5.TabIndex = 17;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(5, 199);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(275, 54);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "通信模式";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(174, 24);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(71, 16);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "2.4G通信";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(27, 24);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "红外通信";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(123, 257);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 22);
            this.button2.TabIndex = 21;
            this.button2.Text = "初始化";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox_Kd);
            this.groupBox6.Controls.Add(this.textBox13);
            this.groupBox6.Controls.Add(this.textBox_Ki);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Controls.Add(this.textBox_Kp);
            this.groupBox6.Controls.Add(this.textBox8);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Location = new System.Drawing.Point(5, 100);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(275, 95);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "PID参数";
            // 
            // textBox_Kd
            // 
            this.textBox_Kd.Location = new System.Drawing.Point(57, 64);
            this.textBox_Kd.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Kd.Name = "textBox_Kd";
            this.textBox_Kd.ReadOnly = true;
            this.textBox_Kd.Size = new System.Drawing.Size(77, 21);
            this.textBox_Kd.TabIndex = 21;
            this.textBox_Kd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(166, 64);
            this.textBox13.Margin = new System.Windows.Forms.Padding(2);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(77, 21);
            this.textBox13.TabIndex = 22;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Ki
            // 
            this.textBox_Ki.Location = new System.Drawing.Point(57, 39);
            this.textBox_Ki.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Ki.Name = "textBox_Ki";
            this.textBox_Ki.ReadOnly = true;
            this.textBox_Ki.Size = new System.Drawing.Size(77, 21);
            this.textBox_Ki.TabIndex = 19;
            this.textBox_Ki.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(166, 39);
            this.textBox11.Margin = new System.Windows.Forms.Padding(2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(77, 21);
            this.textBox11.TabIndex = 20;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Kp
            // 
            this.textBox_Kp.Location = new System.Drawing.Point(57, 14);
            this.textBox_Kp.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_Kp.Name = "textBox_Kp";
            this.textBox_Kp.ReadOnly = true;
            this.textBox_Kp.Size = new System.Drawing.Size(77, 21);
            this.textBox_Kp.TabIndex = 17;
            this.textBox_Kp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(166, 14);
            this.textBox8.Margin = new System.Windows.Forms.Padding(2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(77, 21);
            this.textBox8.TabIndex = 18;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 66);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 12);
            this.label23.TabIndex = 11;
            this.label23.Text = "KD";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 42);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 10;
            this.label22.Text = "KI";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 17);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(17, 12);
            this.label20.TabIndex = 9;
            this.label20.Text = "KP";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(86, 12);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 14;
            this.label18.Text = "当前";
            // 
            // wendu
            // 
            this.wendu.Controls.Add(this.textBox_tempUpLimit);
            this.wendu.Controls.Add(this.label7);
            this.wendu.Controls.Add(this.label9);
            this.wendu.Controls.Add(this.textBox_tempLowLimit);
            this.wendu.Controls.Add(this.textBox3);
            this.wendu.Controls.Add(this.textBox5);
            this.wendu.Location = new System.Drawing.Point(2, 26);
            this.wendu.Margin = new System.Windows.Forms.Padding(2);
            this.wendu.Name = "wendu";
            this.wendu.Padding = new System.Windows.Forms.Padding(2);
            this.wendu.Size = new System.Drawing.Size(275, 70);
            this.wendu.TabIndex = 20;
            this.wendu.TabStop = false;
            this.wendu.Text = "温度设置";
            // 
            // textBox_tempUpLimit
            // 
            this.textBox_tempUpLimit.Location = new System.Drawing.Point(60, 19);
            this.textBox_tempUpLimit.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_tempUpLimit.Name = "textBox_tempUpLimit";
            this.textBox_tempUpLimit.ReadOnly = true;
            this.textBox_tempUpLimit.Size = new System.Drawing.Size(77, 21);
            this.textBox_tempUpLimit.TabIndex = 11;
            this.textBox_tempUpLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 24);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "温度上限";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 47);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "温度下限";
            // 
            // textBox_tempLowLimit
            // 
            this.textBox_tempLowLimit.Location = new System.Drawing.Point(60, 46);
            this.textBox_tempLowLimit.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_tempLowLimit.Name = "textBox_tempLowLimit";
            this.textBox_tempLowLimit.ReadOnly = true;
            this.textBox_tempLowLimit.Size = new System.Drawing.Size(77, 21);
            this.textBox_tempLowLimit.TabIndex = 12;
            this.textBox_tempLowLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(169, 46);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(77, 21);
            this.textBox3.TabIndex = 16;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(169, 19);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(77, 21);
            this.textBox5.TabIndex = 13;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(11, 117);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 19;
            this.label21.Text = "温度下限";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(200, 257);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 22);
            this.button1.TabIndex = 17;
            this.button1.Text = "上传更改";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(196, 12);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 15;
            this.label19.Text = "设置";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.Graph);
            this.panel4.Location = new System.Drawing.Point(704, 222);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(338, 420);
            this.panel4.TabIndex = 16;
            // 
            // Graph
            // 
            this.Graph.BackColor = System.Drawing.Color.White;
            this.Graph.Controls.Add(this.button6);
            this.Graph.Location = new System.Drawing.Point(20, 15);
            this.Graph.Margin = new System.Windows.Forms.Padding(2);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(300, 394);
            this.Graph.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(201, 357);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(97, 33);
            this.button6.TabIndex = 16;
            this.button6.Text = "绘图测试";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(700, 200);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "图像显示";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(412, 367);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "系统信息";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.textBox_SysInfo);
            this.panel3.Location = new System.Drawing.Point(410, 392);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(282, 250);
            this.panel3.TabIndex = 13;
            // 
            // textBox_SysInfo
            // 
            this.textBox_SysInfo.Location = new System.Drawing.Point(2, 7);
            this.textBox_SysInfo.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_SysInfo.Multiline = true;
            this.textBox_SysInfo.Name = "textBox_SysInfo";
            this.textBox_SysInfo.ReadOnly = true;
            this.textBox_SysInfo.Size = new System.Drawing.Size(276, 398);
            this.textBox_SysInfo.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei Light", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(700, 30);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "状态值";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.textBox_EKFTemper2);
            this.panel6.Controls.Add(this.textBox_EKFTemper1);
            this.panel6.Controls.Add(this.textBox_OringinTemper2);
            this.panel6.Controls.Add(this.textBox_OringinTemper1);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Location = new System.Drawing.Point(704, 53);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(338, 140);
            this.panel6.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(76, 10);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "传感器";
            // 
            // textBox_EKFTemper2
            // 
            this.textBox_EKFTemper2.Location = new System.Drawing.Point(178, 58);
            this.textBox_EKFTemper2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_EKFTemper2.Name = "textBox_EKFTemper2";
            this.textBox_EKFTemper2.ReadOnly = true;
            this.textBox_EKFTemper2.Size = new System.Drawing.Size(77, 21);
            this.textBox_EKFTemper2.TabIndex = 14;
            this.textBox_EKFTemper2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_EKFTemper1
            // 
            this.textBox_EKFTemper1.Location = new System.Drawing.Point(178, 29);
            this.textBox_EKFTemper1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_EKFTemper1.Name = "textBox_EKFTemper1";
            this.textBox_EKFTemper1.ReadOnly = true;
            this.textBox_EKFTemper1.Size = new System.Drawing.Size(77, 21);
            this.textBox_EKFTemper1.TabIndex = 13;
            this.textBox_EKFTemper1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_OringinTemper2
            // 
            this.textBox_OringinTemper2.Location = new System.Drawing.Point(58, 56);
            this.textBox_OringinTemper2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_OringinTemper2.Name = "textBox_OringinTemper2";
            this.textBox_OringinTemper2.ReadOnly = true;
            this.textBox_OringinTemper2.Size = new System.Drawing.Size(77, 21);
            this.textBox_OringinTemper2.TabIndex = 12;
            this.textBox_OringinTemper2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_OringinTemper1
            // 
            this.textBox_OringinTemper1.Location = new System.Drawing.Point(58, 29);
            this.textBox_OringinTemper1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_OringinTemper1.Name = "textBox_OringinTemper1";
            this.textBox_OringinTemper1.ReadOnly = true;
            this.textBox_OringinTemper1.Size = new System.Drawing.Size(77, 21);
            this.textBox_OringinTemper1.TabIndex = 11;
            this.textBox_OringinTemper1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(185, 10);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 10;
            this.label15.Text = "EKF算法温度";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 60);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 9;
            this.label16.Text = "水温";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 29);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "室温";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1056, 651);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "数字PWM温度控制系统上位机";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.wendu.ResumeLayout(false);
            this.wendu.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.Graph.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_OpenCOM;
        private System.Windows.Forms.RadioButton radioButton_SellectComFromDetect;
        private System.Windows.Forms.RadioButton radioButton_SellectComFromAll;
        private System.Windows.Forms.ComboBox comboBox_ComSellect;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_AutoSend;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton_SendMode2;
        private System.Windows.Forms.RadioButton radioButton_SendMode1;
        private System.Windows.Forms.Button button_Send;
        private System.Windows.Forms.Button button_SendBoxClear;
        private System.Windows.Forms.TextBox textBox_SendText;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_ReceivedText;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButton_ReceiveMode2;
        private System.Windows.Forms.RadioButton radioButton_ReceiveMode1;
        private System.Windows.Forms.Button button_ReceiveBoxClear;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox_tempLowLimit;
        private System.Windows.Forms.TextBox textBox_tempUpLimit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel Graph;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox_SysInfo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_BaundRate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox_StopBitNum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox_CheckBitNum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox_DataBitNum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox_EKFTemper1;
        private System.Windows.Forms.TextBox textBox_OringinTemper2;
        private System.Windows.Forms.TextBox textBox_OringinTemper1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_EKFTemper2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox wendu;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox_Kd;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox_Ki;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox_Kp;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ToolStripMenuItem 作者ToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}

